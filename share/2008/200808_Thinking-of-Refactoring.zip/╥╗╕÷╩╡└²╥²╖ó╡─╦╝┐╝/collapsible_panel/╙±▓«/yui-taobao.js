/*!
Copyright (c) 2008, TAOBAO.COM Inc. All rights reserved.
*/

TAOBAO = { version: '0.3.0' };

TAOBAO.namespace = function() {
    var o = null, i, j, parts;
    for (i = 0; i < arguments.length; ++i) {
        parts = arguments[i].split('.');
        o = TAOBAO;

        // TAOBAO is implied, so it is ignored if it is included
        for (j = (parts[0] == "TAOBAO") ? 1 : 0; j < parts.length; ++j) {
            o[parts[j]] = o[parts[j]] || {};
            o = o[parts[j]];
        }
    }

    return o;
};

TAOBAO.namespace('env', 'lang', 'util', 'widget', 'example');
YAHOO.lang.augmentObject(TAOBAO.env, YAHOO.env);
YAHOO.lang.augmentObject(TAOBAO.lang, YAHOO.lang);
YAHOO.lang.augmentObject(TAOBAO.util, YAHOO.util);
YAHOO.lang.augmentObject(TAOBAO.widget, YAHOO.widget);

/*
 * languange utilites and extensions
 * Ref:
 *  - Ext/Ext.js 2.1
 *  - http://developer-test.mozilla.org/docs/Core_JavaScript_1.5_Reference
 *  - prototype-1.6.0.2.js
 *
 * creator: yubo@taobao.com
 */

/**
 * Copies all the properties of config to obj.
 * @param {Object} obj The receiver of the properties
 * @param {Object} config The source of the properties
 * @param {Object} defaults A different object that will also be applied for default values
 * @return {Object} returns obj
 */
TAOBAO.lang.apply = function(o, c, defaults) {
    if(defaults) {
        // no "this" reference for friendly out of scope calls
        TAOBAO.apply(o, defaults);
    }
    if(o && c && typeof c == 'object') {
        for(var p in c) {
            o[p] = c[p];
        }
    }
    return o;
};

TAOBAO.lang.apply(TAOBAO.lang, {
	/**
	 * Copies all the properties of config to obj if they don't already exist.
	 * @param {Object} obj The receiver of the properties
	 * @param {Object} config The source of the properties
	 * @return {Object} returns obj
	 */
	applyIf: function(o, c) {
	    if(o && c) {
	        for(var p in c) {
	            if(typeof o[p] == 'undefined') {
	            	o[p] = c[p];
	            }
	        }
	    }
	    return o;
	},
	/**
	 * Ext like extend
	 */
	extend: function(subclass, superclass, overrides) {
		if(arguments.length == 2 && typeof overrides == 'object') {
			subclass = function() { };
		}
		
		YAHOO.lang.extend(subclass, superclass, overrides);
		return subclass;
	}
});

// shorthands
TAOBAO.extend = TAOBAO.lang.extend;

/**
 * @class String
 * These functions are available as static methods on the JavaScript String object.
 */
TAOBAO.lang.applyIf(String, {
    /**
     * Escapes the passed string for ' and \
     * @param {String} string The string to escape
     * @return {String} The escaped string
     * @static
     */
    escape: function(string) {
        return string.replace(/('|\\)/g, '\\$1');
    },

    /**
     * Pads the left side of a string with a specified character.  This is especially useful
     * for normalizing number and date strings.  Example usage:
     * <pre>
	 | var s = String.leftPad('123', 5, '0');
	 | // s now contains the string: '00123'
	 * </pre>
     * @param {String} string The original string
     * @param {Number} size The total length of the output string
     * @param {String} char (optional) The character with which to pad the original string (defaults to empty string " ")
     * @return {String} The padded string
     * @static
     */
    leftPad: function (val, size, ch) {
        var result = new String(val);
        if(!ch) {
            ch = ' ';
        }
        while (result.length < size) {
            result = ch + result;
        }
        return result.toString();
    },
    /**
     * Allows you to define a tokenized string and pass an arbitrary number of arguments to replace the tokens.  Each
     * token must be unique, and must increment in the format {0}, {1}, etc.  Example usage:
     * <pre>
	 | var cls = 'my-class', text = 'Some text';
	 | var s = String.format('&lt;div class="{0}">{1}&lt;/div>', cls, text);
	 | // s now contains the string: '&lt;div class="my-class">Some text&lt;/div>'
	 * </pre>
     * @param {String} string The tokenized string to be formatted
     * @param {String} value1 The value to replace token {0}
     * @param {String} value2 Etc...
     * @return {String} The formatted string
     * @static
     */
    format: function(format){
        var args = Array.prototype.slice.call(arguments, 1);
        return format.replace(/\{(\d+)\}/g, function(m, i) {
            return args[i];
        });
    }
});

/**
 * @class String
 */
TAOBAO.lang.applyIf(String.prototype, {
	/**
	 * Trims whitespace from either end of a string, leaving spaces within the string intact.  Example:
	 * <pre>
	 | var s = '  foo bar  ';
	 | alert('-' + s + '-');         //alerts "- foo bar -"
	 | alert('-' + s.trim() + '-');  //alerts "-foo bar-"
	 * </pre>
	 * @return {String} The trimmed string
	 */
	trim: function() {
	    return this.replace(/^\s+|\s+$/g, '');
	},
	/**
	 * Strips a string of any HTML tag.
	 * <pre>
	 | 'a <a href="#">link</a><script>alert("hello world!")</script>'.stripTags();
	 | // -> 'a linkalert("hello world!")'
	 * </pre>
	 *@return {String} The stripped string
	 */
	stripTags: function() {
		return this.replace(/<.*?>/g, '');
		//return this.replace(/<\/?[^>]+>/g, '');
	},
	/**
	 * Utility function that allows you to easily switch a string between two alternating values.  The passed value
	 * is compared to the current string, and if they are equal, the other value that was passed in is returned.  If
	 * they are already different, the first value passed in is returned.  Note that this method returns the new value
	 * but does not change the current string.
	 * <pre>
	 | // alternate sort directions
	 | sort = sort.toggle('ASC', 'DESC');
	 |
	 | // instead of conditional logic:
	 | sort = (sort == 'ASC' ? 'DESC' : 'ASC');
	 | </pre>
	 * @param {String} value The value to compare to the current string
	 * @param {String} other The new value to use if the string already equals the first value passed in
	 * @return {String} The new value
	 */
	toggle: function(value, other) {
	    return this == value ? other : value;
	},
	/**
	 * Checks if the string ends with substring.
	 * <pre>
	 | 'slaughter'.endsWith('laughter')
	 | // -> true
	 * </pre>
	 */
	endsWith: function(substring) {
		var p = this.length - substring.length;
		return p >= 0 && this.lastIndexOf(substring) === p;
	}
});

/**
 * @class Array
 */
TAOBAO.lang.applyIf(Array.prototype, {
    /**
     * Checks whether or not the specified object exists in the array.
     * @param {Object} o The object to check for
     * @return {Number} The index of o in the array (or -1 if it is not found)
     */
    indexOf: function (o, fromIndex) {
		if (fromIndex == null) {
			fromIndex = 0;
		} else if (fromIndex < 0) {
			fromIndex = Math.max(0, this.length + fromIndex);
		}
		for (var i = fromIndex; i < this.length; i++) {
			if (this[i] === o)
				return i;
		}
		return -1;
    },
	contains: function(o) {
		return this.indexOf(o) != -1;
	},
    
    /**
     * Removes the specified object from the array.  If the object is not found nothing happens.
     * @param {Object} o The object to remove
     * @return {Array} this array
     */
    remove: function(o) {
       var index = this.indexOf(o);
       if(index != -1){
           this.splice(index, 1);
       }
       return this;
    },
    
    /**
     * Ref: http://developer.mozilla.org/en/docs/Core_JavaScript_1.5_Reference:Global_Objects:Array:forEach
     */
    forEach: function(fun /*, thisp*/) {
		var len = this.length;
		if (typeof fun != "function")
		  throw new TypeError();

		var thisp = arguments[1];
		for (var i = 0; i < len; ++i) {
		  if (i in this) fun.call(thisp, this[i], i, this);
		}
	}
});

/**
 * @class Number
 */
TAOBAO.lang.applyIf(Number.prototype, {
    /**
     * Checks whether or not the current number is within a desired range.  If the number is already within the
     * range it is returned, otherwise the min or max value is returned depending on which side of the range is
     * exceeded.  Note that this method returns the constrained value but does not change the current number.
     * @param {Number} min The minimum number in the range
     * @param {Number} max The maximum number in the range
     * @return {Number} The constrained value if outside the range, otherwise the current value
     */
    constrain: function(min, max) {
        return Math.min(Math.max(this, min), max);
    }
});
/*
 * DOM utilites
 *
 * creator: yubo@taobao.com
 */

TAOBAO.util.Dom = { };
TAOBAO.lang.augmentObject(TAOBAO.util.Dom, YAHOO.util.Dom);

TAOBAO.lang.apply(TAOBAO.util.Dom, function() {
	var D = TAOBAO.util.Dom,
		L = TAOBAO.lang;
	
	return {
		/**
		 * �л�Ԫ�ص�class
		 * @param {String | HTMLElement} el
		 * @param {String} classA
		 * @param {String} [optional] classB
		 */
		toggleClass: function(el, classA, classB) {
			if(!el || !classA) return;
			
			if(D.hasClass(el, classA)) {
				if(classB) {
					D.replaceClass(el, classA, classB);
				} else {
					D.removeClass(el, classA);
				}
			} else {
				if (classB && D.hasClass(el, classB)) {
					D.replaceClass(el, classB, classA);
				} else {
					D.addClass(el, classA);
				}
			}
		},
		
		/**
		 * �л�Ԫ�صĿɼ���
		 *  @param {String | HTMLElement}
		 */
		toggleDisplay: function(el) {
			var isHidden = D.getStyle(el, 'display').toLowerCase() == 'none';
			D.setStyle(el, 'display', isHidden ? '' : 'none');
		},
		
		/**
		 * ����ClassName��ȡ��һ��Ԫ��
		 * û���ҵ�ʱ����null
		 */
		getFirstElementByClassName: function(className, tag, root) {
			var results = D.getElementsByClassName(className, tag, root);
						
			if(results.length == 0) return null;
			return results[0];
		},
		
		/**
		 * ����TagName��ȡ��һ��Ԫ��
		 * û���ҵ�ʱ����null
		 */
		getFirstElementByTagName: function(tag, root) {
			root = D.get(root);
			if(!root) return null;
			var results = root.getElementsByTagName(tag);
						
			if(results.length == 0) return null;
			return results[0];
		}
	};
}());

/*
 * Event utilites
 *
 * creator: yubo@taobao.com
 */

TAOBAO.util.Event = { };
TAOBAO.lang.augmentObject(TAOBAO.util.Event, YAHOO.util.Event);

TAOBAO.lang.apply(TAOBAO.util.Event, function() {
	var L  = TAOBAO.lang,
		U  = TAOBAO.util,
		D  = TAOBAO.util.Dom;

	return {
		/**
		 * ����Ԫ�ص��¼�
		 *
		 * @param {String | HTMLElement} el
		 * @param {String} [optional] eventName default is 'click'
		 */
		fireElEvent: function(el, eventName) {	
			el = D.get(el);
			if(!el) return;
			eventName = eventName || 'click';
			
			if (document.createEvent) {
				var evObj = document.createEvent('MouseEvents');
				evObj.initEvent(eventName, true, false);
				el.dispatchEvent(evObj);
			}
			else if (document.createEventObject) {
			   el.fireEvent('on' + eventName);
			}
		},
		
		/**
		 * ˵����YAHOO.util.Event.on([], 'click', func) ���������
		 * �����װһ�£�ʹ�� E.on([], ...) �� E.on(null, ...) һ��������
		 */
		addListener: function(el, sType, fn, obj, override) {
			if(L.isArray(el) && el.length == 0) return false;
			
			return YAHOO.util.Event.addListener(el, sType, fn, obj, override);
		},
		on: function(el, sType, fn, obj, override) {
			return this.addListener(el, sType, fn, obj, override);
		},
		
		/**
		 * Used to add events on object
		 */
		addEvents: function() {
			if(!this.events) this.events = { };
			
			var obj = this;
			var eventNames = arguments;
			for(var i = 0, len = eventNames.length; i < len; ++i) {
				(function() {
					var eventName = eventNames[i];
					if(typeof eventName != 'string') return;
					
					obj.events[eventName] = new U.CustomEvent(eventName, null, false, U.CustomEvent.FLAT);
					
					if(obj.config && obj.config.events && obj.config.events[eventName]) {
						obj.events[eventName].subscribe(obj.config.events[eventName]);
					}
					
					//obj[eventName] = function(fn) {
					//	if(obj.events[eventName]) obj.events[eventName].subscribe(fn);
					//};
					obj[eventName] = obj.events[eventName];
				})();
			}
		}
	};
}());

/*
 * Selector utilites
 *
 * creator: yubo@taobao.com
 */
TAOBAO.util.Selector = { };
TAOBAO.lang.augmentObject(TAOBAO.util.Selector, YAHOO.util.Selector);

TAOBAO.lang.apply(TAOBAO.util.Selector, function() {
	var D = TAOBAO.util.Dom,
		L = TAOBAO.lang;
	
	return {
		/**
		 * Retrieves a set of nodes based on a given CSS selector. 
		 * @param {string} selector The CSS Selector to test the node against.
		 * @param {HTMLElement | String} root optional An id or HTMLElement to start the query from. Defaults to Selector.document.
		 * @param {Boolean} firstOnly optional Whether or not to return only the first match.
		 * @param {Function} apply optional A function to apply to each element when found
		 * @return {HTMLElement | Array | Any} An array of nodes that match the given selector.
		 */
		query : function(selector, root, firstOnly, apply) {			
			if(L.isBoolean(root)) { firstOnly = root; root = null; }
			if(L.isFunction(root)) { apply = root; root = firstOnly = null; }
			if(L.isFunction(firstOnly)) { apply = firstOnly; firstOnly = null; }

			var collection = YAHOO.util.Selector.query(selector, root, firstOnly);
			if(L.isFunction(apply)) return D.batch(collection, apply);
			return collection;
		}
	};
}());

/*
 * common utilites
 * Ref:
 *  - Ext/Ext.js 2.1
 *  - http://developer-test.mozilla.org/docs/Core_JavaScript_1.5_Reference
 *
 * creator: yubo@taobao.com
 */

TAOBAO.lang.apply(TAOBAO.util, function() {
	var L = TAOBAO.lang;
	
	return {
		/**
		 * Takes an object and converts it to an encoded URI-like query.
		 * e.g. TAOBAO.util.urlEncode({foo: 1, bar: 2}); would return "foo=1&bar=2".
		 * Optionally, property values can be arrays, instead of keys 
		 * and the resulting string that's returned will contain a name/value pair for each array value.
		 * @param {Object} o
		 * @return {String}
		 */
		encodeUriQuery : function(o) {
		    if(!o) return '';

		    var buf = [];
		    for(var key in o) {
		        var ov = o[key], k = encodeURIComponent(key);
		        var type = typeof ov;
		        if(type == 'undefined') {
		            buf.push(k, '=&');
		        }else if(type != 'function' && type != 'object') {
		            buf.push(k, '=', encodeURIComponent(ov), '&');
		        }else if(L.isArray(ov)) {
		            if (ov.length) {
		                for(var i = 0, len = ov.length; i < len; i++) {
		                    buf.push(k, '=', encodeURIComponent(ov[i] === undefined ? '' : ov[i]), '&');
		                }
		            } else {
		                buf.push(k, '=&');
		            }
		        }
		    }
		    buf.pop();
		    return buf.join('');
		},
		
		/**
		 * Parses a URI-like query string and returns an object composed of parameter/value pairs.
		 * This method is realy targeted at parsing query strings (hence the default value of "&" for the separator argument).
		 * For this reason, it does not consider anything that is either before a question 
		 * mark (which signals the beginning of a query string) or beyond the hash symbol ("#"), 
		 * and runs decodeURIComponent() on each parameter/value pair.
		 * Note that parameters which do not have a specified value will be set to undefined.
		 * e.g. TAOBAO.util.urlDecode("foo=1&bar=2"); would return {foo: 1, bar: 2} 
		 * or TAOBAO.util.urlDecode("foo=1&bar=2&bar=3&bar=4", true); would return {foo: 1, bar: [2, 3, 4]}.
		 * <pre>
		 | 'section=blog&id=45'
		 | // -> {section: 'blog', id: '45'}
		 |
		 | 'section=blog;id=45', false, ';'
		 | // -> {section: 'blog', id: '45'}
		 |
		 | 'http://www.example.com?section=blog&id=45#comments'
		 | // -> {section: 'blog', id: '45'}
		 |
		 | 'section=blog&tag=javascript&tag=prototype&tag=doc'
		 | // -> {section: 'blog', tag: ['javascript', 'prototype', 'doc']}
		 |
		 | 'tag=ruby%20on%20rails'
		 | // -> {tag: 'ruby on rails'}
		 |
		 | 'id=45&raw'
		 | // -> {id: '45', raw: undefined}
		 * </pre>
		 * @param {String} string
		 * @param {Boolean} overwrite (optional) Items of the same name will overwrite previous values instead of creating an an array (Defaults to false).
		 * @return {Object} A literal with members
		 */
		decodeUriQuery : function(string, overwrite, separator) {
			if(!string || !string.length) return { };
		    
			var match = string.trim().match(/([^?#]*)(#.*)?$/);
			if (!match) return { };
			
		    var obj = { };
		    var pairs = match[1].split(separator || '&');
		    
		    var pair, name, value;
		    for(var i = 0, len = pairs.length; i < len; i++) {
		        pair = pairs[i].split('=');
		        name = decodeURIComponent(pair[0]);
		        value = decodeURIComponent(pair[1]);
		        if(overwrite !== true) {
		            if(typeof obj[name] == 'undefined') {
		                obj[name] = value;
		            } else if(typeof obj[name] == 'string') {
		                obj[name] = [obj[name]];
		                obj[name].push(value);
		            } else {
		                obj[name].push(value);
		            }
		        } else {
		            obj[name] = value;
		        }
		    }
		    return obj;
		}
	};
}());

/*
 * Effect utilites
 *
 * creator: yubo@taobao.com
 */
TAOBAO.util.Effect = { };

TAOBAO.lang.apply(TAOBAO.util.Effect, function() {
	var D = TAOBAO.util.Dom,
		E = TAOBAO.util.Event,
		L = TAOBAO.lang;
	
	return {
		/** 
		 * ͨ���߶ȵı仯����������ʾ/����Ԫ��
		 */
		slideToggle: function(el, duration, easing, callback, thisObj) {
			el = D.get(el);
			if(!el) return;
			
			var isHidden = (D.getStyle(el, 'height').toLowerCase() == '0px');
			this[isHidden ? 'slideDown' : 'slideUp'](el, duration, easing, callback, thisObj);
		},
		slideDown: function(el, duration, easing, callback, thisObj) {
			el = D.get(el);
			if(!el) return;
			D.setStyle(el, 'overflow', 'hidden'); // ��֤height����Ĳ���������
			D.setStyle(el, 'height', '0');

			var attributes = { height: { to: el.scrollHeight } };
			var anim = new TAOBAO.util.Anim(el, attributes, duration, easing);
			anim.onComplete.subscribe(function() { 
					//[fix bug] ����к�������壬�����չ��ʱ�����ĸ߶�δ����Ӧ
					D.setStyle(el, 'height', 'auto'); 
				});
			if(callback) anim.onComplete.subscribe(callback, thisObj, true);
			
			anim.animate();
		},
		slideUp: function(el, duration, easing, callback, thisObj) {
			el = D.get(el);
			if(!el) return;
			D.setStyle(el, 'overflow', 'hidden'); // ��֤height����Ĳ���������
			
			var attributes = { height: { to: '0' } };
			var anim = new TAOBAO.util.Anim(el, attributes, duration, easing);
			if(callback) anim.onComplete.subscribe(callback, thisObj, true);
			
			anim.animate();	
		},
		
		/**
		 * Fade the opacity of all matched elements to a specified opacity and firing an optional callback after completion. 
		 * Only the opacity is adjusted for this animation, meaning that all of the matched elements should already 
		 * have some form of height and width associated with them.
		 */
		fadeTo: function(el, duration, opacity, easing, callback, thisObj) {
			el = D.get(el);
			if(!el) return;
			
			var attributes = { opacity: { to: opacity } };
			var anim = new TAOBAO.util.Anim(el, attributes, duration, easing);
			if(callback) anim.onComplete.subscribe(callback, thisObj, true);
			
			anim.animate();	
		},
		fadeIn: function(el, duration, easing, callback, thisObj) {
			throw new Error('��δʵ��');
		},
		fadeOut: function(el, duration, easing, callback, thisObj) {
			this.fadeTo(el, duration, 0, easing, callback, thisObj);
		}
	};
}());

/**
 * @class TAOBAO.widget.Panel
 *
 * creator: yubo@taobao.com
 */

TAOBAO.widget.Panel = function() {
	var L  = TAOBAO.lang,
		U  = TAOBAO.util,
		D  = TAOBAO.util.Dom,
		E  = TAOBAO.util.Event,
		Ef = TAOBAO.util.Effect;

	// Ĭ������
	var defConfig = {
			container: null, 
			
			/* ��panel�ﺬ��panelʱ��ͨ��cls��ȷ��head��body��foot�ǲ��ɿ���
			 *
			 * ��RoR������������������ԭ������������cls���������Ǳ����
			 * container��chidren�У�
			 * �� children.length == 1ʱ��body = children[0]
			 * �� children.length == 3ʱ�����θ�head, body, foot��ֵ
			 * �� children.length == 2ʱ���Ÿ���bodyCls������
			 * ���ɣ�body��Ҫʼ���еģ����û�У��Ͳ�Ӧ����Panel
			 */
			//headCls: 'hd',
			bodyCls: 'bd',
			//footCls: 'ft',
				
			collapsible: false,
			collapsed: false,
			collapsedCls: 'collapsed',
			titleCollapse: false, // ����title�ڵ��ʱ������collapse�л�
			toggleCls: 'tool-toggle',
			animCollapse: false,
			animDuration: 0.25,
			animEasing: U.Easing.easeNone,
			
			//draggable: null, // TODO
			//shadow: null, // TODO
			
			events: { }
		};
	
	var Panel = function() {
		var args = arguments;
		if(args.length == 1) {
			if(typeof args[0] == 'string' || args[0].nodeType == 1) { // new Panel('panelId')
				init.call(this, { container: args[0] });
			} else if(typeof args[0] == 'object') { // new Panel( {container: 'id', collapsible: true, ... } )
				init.call(this, args[0]);
			}
		} else if(args.length == 2) {
			// new Panel('panelId', {collapsible: true, ...} )
			if((typeof args[0] == 'string' || args[0].nodeType == 1) && typeof args[1] == 'object') {
				args[1].container = args[0];
				init.call(this, args[1]);
			}
		} else {
			return null;
		}
	};

	function init(config) {
		this.config = L.applyIf(config || {}, defConfig);

		var cfg = this.config;
		this.container = D.get(cfg.container);
		if(!this.container) return;
		
		// �μ� defConfig���˵��
		var children = D.getChildren(this.container);
		var len = children.length;
		if(len == 1) {
			this.body = children[0];
		} else if(len == 2) {
			if(D.hasClass(children[0], cfg.bodyCls)) {
				this.body = children[0];
				this.foot = children[1];
			} else {
				this.head = children[0];
				this.body = children[1];
			}
		} else if(len == 3) {
			this.head = children[0];
			this.body = children[1];
			this.foot = children[2];
		} else {
			return;
		}
		
		// init collapsible
		if(cfg.collapsible) {
			var toggle;
			// �ȴ�ͷ����ȡtoggle��δ�õ�ʱ���ٳ��Դ�foot�л�ȡ
			if(this.head) toggle = D.getFirstElementByClassName(cfg.toggleCls, null, this.head);
			if(!toggle && this.foot) toggle = D.getFirstElementByClassName(cfg.toggleCls, null, this.foot);
			
			if(!toggle) { // û��ʱ������
				toggle = document.createElement('div');
				D.addClass(toggle, cfg.toggleCls);
				this.head.appendChild(toggle);
			}
						
			if(YAHOO.env.ua.ie === 6) { // ie6�£�hasLayout��Ԫ�زſ��Ե��
				D.setStyle(this.head, 'zoom', '1');
			}
			
			// �����¼�
			E.addEvents.apply(this, ['onCollapse', 'beforeCollapse', 'onExpand', 'beforeExpand']);
			
			E.on(cfg.titleCollapse ? this.head : toggle, 'click', function(e) {
				E.preventDefault(e); // toggle maybe a
				this.toggleCollapse();
			}, null, this);
			
			this.collapsed = false;
			if(cfg.collapsed) {
				this.collapse(false);
			}
		}
	};

	Panel.prototype = {
		/**
		 * ��ȡ��panel�������domԪ��
		 */
		getDom: function() {
			return this.container;
		},
		
		/**
		 * Collapses the panel body so that it becomes hidden. 
		 * Fires the beforeCollapse event which will cancel the collapse action if it returns false.
		 *
		 * @param {Boolean} anmiate True to animate the transition, else false (defaults to the value of the animCollapse config)
		 */
		collapse: function(animate) {
			if(this.collapsed) return;
			if(this.events['beforeCollapse'].fire(this) === false) return;
			
			if(typeof animate != 'boolean') animate = this.config.animCollapse;
			if(animate) {				
				var callback = 	function() {
						D.addClass(this.getDom(), this.config.collapsedCls);
						this.events['onCollapse'].fire(this);
					};
				Ef.slideUp(this.body, this.config.animDuration, this.config.animEasing, callback, this);
			} else {
				D.setStyle(this.body, 'display', 'none');
				D.addClass(this.getDom(), this.config.collapsedCls);
			}

			this.collapsed = true;
		},
		expand: function(animate) {
			if(!this.collapsed) return;
			D.removeClass(this.getDom(), this.config.collapsedCls);
			if(this.events['beforeExpand'].fire(this) === false) return;
			
			D.setStyle(this.body, 'display', '');
			if(typeof animate != 'boolean') animate = this.config.animCollapse;
			if(animate) {
				var callback = 	function() {
						this.events['onExpand'].fire(this);
					};
				Ef.slideDown(this.body, this.config.animDuration, this.config.animEasing, callback, this);
 			}

			this.collapsed = false;
		},
		toggleCollapse: function(animate) {
			this[this.collapsed ? 'expand' : 'collapse'](animate);
		}
	};
	
	return Panel;
}();

// ����decorate��̬����
TAOBAO.widget.Panel.decorate = function(container, panelCfg) {
	return new TAOBAO.widget.Panel(container, panelCfg);
};
/**
 * @class TAOBAO.widget.PanelList
 *
 * creator: yubo@taobao.com
 */

TAOBAO.widget.PanelList = function() {
	var L  = TAOBAO.lang,
		U  = TAOBAO.util,
		D  = TAOBAO.util.Dom,
		E  = TAOBAO.util.Event;

	// Ĭ������
	var defConfig = {
			container: null,
			recursive: false, // �ݹ��ȡ����panels
			panelCls: 'tb-panel' // recursive === trueʱ���Դ���Ϊ��ȡpanelsʱ�ı�־��
		};
	
	var PanelList = function() {
		var cfgs = this.parseArguments(arguments);
		var config = cfgs[0], panelConfig = cfgs[1];

		// ��ȡĬ������
		config = L.applyIf(config, defConfig);
		init.call(this, config, panelConfig);		
	};

	function init(config, panelConfig) {
		this.config = L.applyIf(config || {}, defConfig);
		panelConfig = panelConfig || {};
		
		var cfg = this.config;
		this.container = D.get(cfg.container);
		if(!this.container) return;
		
		// init panels
		if(cfg.recursive) {
			var domPanels = D.getElementsByClassName(cfg.panelCls, null, this.container);
		} else {
			var domPanels = D.getChildren(this.container);
		}
		this.panels = [];
		for(var i = 0, len = domPanels.length; i < len; ++i) {
			panelConfig.container = domPanels[i];
			this.panels.push(new TAOBAO.widget.Panel(panelConfig));
		}
		
		this.length = this.panels.length;
	}
	
	PanelList.prototype = {
		// static
		parseArguments: function(args) {
			var validArgs = [];
			for(var i = 0, len = args.length; i < len; ++i) {
				if(typeof args[i] != 'undefined')
					validArgs.push(args[i]);
			}
			args = validArgs;
			
			var config = {}, panelConfig = {};
			len = args.length;
			
			if(len == 1) {
				if(typeof args[0] == 'string' || args[0].nodeType == 1) { // new PanelList('containerId')
				config = { container: args[0] };
				} else if(typeof args[0] == 'object') { // new PanelList( {container: 'id', recursive: false, ... } )
					config = args[0];
				}
			} else if(len == 2) {
				// new PanelList('containerId', {recursive: false, ...} )
				if((typeof args[0] == 'string' || args[0].nodeType == 1) && typeof args[1] == 'object') {
					config = args[1];
					config.container = args[0];
				// new PanelList(config, panelConfig)
				} else if(typeof args[0] == 'object' && typeof args[1] == 'object') {
					config = args[0];
					panelConfig = args[1];
				}
			} else if(len == 3) {
				// new PanelList('containerId', config, panelConfig)
				if((typeof args[0] == 'string' || args[0].nodeType == 1) && typeof args[2] == 'object') {
					config = args[1] || { }; // args[1]����Ϊnull
					config.container = args[0];
					panelConfig = args[2];
				}
			}
			
			return [config, panelConfig];
		}
	};
	
	return PanelList;
}();

// ����decorate��̬����
TAOBAO.widget.PanelList.decorate = function(container, listCfg, panelCfg) {
	return new TAOBAO.widget.PanelList(container, listCfg, panelCfg);
};/**
 * @class TAOBAO.widget.PanelList
 *
 * creator: yubo@taobao.com
 */

TAOBAO.widget.FoldingList = function() {
	var L  = TAOBAO.lang,
		U  = TAOBAO.util,
		D  = TAOBAO.util.Dom,
		E  = TAOBAO.util.Event;

	// FoldingList��Ĭ������
	// ��PanelList��ͬ����������ο�PanelList.source.js
	var defConfig = {
			multiExpand: true  // true: ����ͬʱչ�����  false��ͬһʱ��ֻ����չ��һ��
		};
	// FoldingList����Panel��Ĭ������
	// ������ο�Panel.source.js
	var defPanelConfig = {
			collapsible: true // ����FoldingList��˵������϶���true���û����ܸ���
		};
	
	var FoldingList = function() {
		var cfgs = this.parseArguments(arguments);
		var config = cfgs[0], panelConfig = cfgs[1];
		
		// ��ȡĬ������
		config = L.applyIf(config, defConfig);
		panelConfig = L.applyIf(panelConfig, defPanelConfig);
		panelConfig.collapsible = true;
		
		// chain ctor
		this.constructor.superclass.constructor.call(this, config, panelConfig);
		
		// ������һչ��
		if(!this.config.multiExpand) {
			processMultiExpand.call(this);
		}
	};
	
	/*
	 * ������һչ��
	 */
	function processMultiExpand() {
		var panels = this.panels;
		for(var i = 0, len = panels.length; i < len; ++i) {
			var panel = panels[i];
			panel.beforeExpand.subscribe(function() {
				for(var j = 0; j < len; ++j) {
					// �ų������͸���panel
					if(panels[j] == this || D.isAncestor(panels[j].getDom(), this.getDom())) continue;
					
					// [bug fix] multiExpandΪtrueʱ������panel�������ٴ�չ��ʱ���������panel��״̬δ����
					// δ����������bug����Ҫ�ж�parentNode�뵱ǰpanel��ͬ�Ĳ�collapse��������panel״̬����Ҫ��
					if(panels[j].getDom().parentNode != this.getDom().parentNode) continue;
					
					panels[j].collapse();
				}
			}, null, panel); 
		}
	}
	
	TAOBAO.extend(FoldingList, TAOBAO.widget.PanelList, {
		expandAll: function() {
			if(!this.config.multiExpand) return;
			
			for(var i = 0, len = this.panels.length; i < len; ++i) {
				this.panels.expand();
			}
		},
		collapseAll: function() {
			for(var i = 0, len = this.panels.length; i < len; ++i) {
				this.panels.collapse();
			}
		}
	});
	
	return FoldingList;
}();

// ����decorate��̬����
TAOBAO.widget.FoldingList.decorate = function(container, listCfg, panelCfg) {
	return new TAOBAO.widget.FoldingList(container, listCfg, panelCfg);
};/**
 * @class TAOBAO.widget.TabView
 *
 * creator: yubo@taobao.com
 * TODO-List:
 * [+] ֧��eventType = 'mouse'
 * [+] ֧��getNavBarFromMackup
 */

TAOBAO.widget.TabView = function() {
	var L  = TAOBAO.lang,
		U  = TAOBAO.util,
		D  = TAOBAO.util.Dom,
		E  = TAOBAO.util.Event;

	// TabView��Ĭ������
	// ��PanelList��ͬ����������ο�PanelList.source.js
	var defConfig = {
			containerCls: 'tv-container',
			navBarCls: 'tv-nav',
			panelsWrapperCls: 'tv-wrapper',
			
			eventType: 'click', // TODO: support 'mouse'
			delay: 0.1, // TODO
			
			activeTabIndex: 0,
			parseHash: false, // ��location.hash�н�����activeTabIndex. Ϊtrueʱ��������activeTabIndex��Ч
			activeTabCls: 'current',
			autoActivateDefaultTab: true, // defaultTab��activeTabIndex����parseHash�õ���ֵ����
			
			viewMode: 'tab', //'tab': ��׼tabviewģʽ��'plain': ������panelƽ��չ����ʾ
			getNavBarFromMackup: false, // ��mockup�л�ȡnavBar��Ĭ���Զ����� TODO
			hiddenPanelHead: true, // viewModeΪ'tab'ʱ���Ƿ�����panel��ͷ
			
			showViewModeToggle: false, // �Ƿ���ʾ ��ʾ��ʽ
			viewModeToggleCls: 'tv-toggle',
			currentViewModeCls: 'current',
			viewModeTips: ['��ʾ��ʽ��', '�б���ʽ', '��ǩҳ��ʽ'], // TODO: support multi lang
			
			events: { }
		};
	
	var TabView = function() {
		var cfgs = this.parseArguments(arguments);
		var config = cfgs[0], panelConfig = cfgs[1];
		
		// ��ȡĬ������
		config = L.applyIf(config, defConfig);
		
		// chain ctor
		this.constructor.superclass.constructor.call(this, config, panelConfig);
		
		init.call(this);
	};
	
	function init() {
		// �����¼�
		E.addEvents.apply(this, ['onSwitchTab', 'beforeSwitchTab', 'onToggleViewMode', 'beforeToggleViewMode']);
				
		// ��ʼ������
		var panelsWrapper = this.container;
		var newContainer = document.createElement('div');
		D.addClass(newContainer, this.config.containerCls);
		panelsWrapper.parentNode.insertBefore(newContainer, panelsWrapper);
		this.container = newContainer;

		// ���ɵ�����
		initNavBar.call(this);
		
		// ��ʼ��Toggle
		if(this.config.showViewModeToggle === true) initViewModeToggle.call(this);
		
		// ��panelsWrapper�Ƶ���������
		D.addClass(panelsWrapper, this.config.panelsWrapperCls);
		this.panelsWrapper = panelsWrapper;
		this.container.appendChild(panelsWrapper);

		// apply ie6 hacks
		hackForIE6(this);
		
		// ��location.hash�н�����activeTabIndex
		if(this.config.parseHash && location.hash) {
			for(var i = 0, len = this.panels.length; i < len; ++i) {
				var tabHash = this.panels[i].tabHead.anchor.name; //.href.match(/#[^?]+/); // hash���Է���?ǰ��Ҳ���������
				if(tabHash == location.hash) {
					this.config.activeTabIndex = i;
					break;
				}
			}
		}
		
		// plain ƽ����ʾ
		if(this.config.viewMode == 'plain') {
			this.toggleViewMode('plain');
		} else { // tab ģʽ��ʾ
			// setActiveTabǰ������������panels
			this.panels.forEach( function(panel) { D.setStyle(panel.getDom(), 'display', 'none'); } );
			
			if(this.config.autoActivateDefaultTab) {
				this.setActiveTab(this.config.activeTabIndex);
			}
		}		
	}
	
	// private members
		/**
		 * ��ʼ��������
		 */
		function initNavBar() {
			var ul = document.createElement('ul');
			D.addClass(ul, this.config.navBarCls);
			
			this.panels.forEach(function(panel, index) {
				var li = document.createElement('li');
				li.setAttribute('rel', index);
				
				// li�����ٷ�һ��a��Ϊ�˸��õĿ�����ʽ���ر���ie6
				var anchor = document.createElement('a');
				anchor.name = '#tab' + index;
				//anchor.appendChild(document.createTextNode(panel.head.innerHTML.stripTags())); // ��ie�»�����ӿհף����
				anchor.innerHTML = panel.head.innerHTML.stripTags();
				li.appendChild(anchor);
				// �����¼�
				E.on(anchor, 'click', function(e) { // ȥ��a�ϵ�Ĭ�ϵ���¼�
					E.preventDefault(e);
				});
				
				// �����li��ʱ�������¼�
				E.on(li, 'click', function(e) {
					if(this.config.activeTabIndex == index) return; // �ظ����
					this.setActiveTab(index); 
				}, null, this);
				
				panel.tabHead = li;
				panel.tabHead.anchor = anchor;
				ul.appendChild(li);
			}, this);
			
			this.navBar = ul;
			this.container.appendChild(ul);
		}
		
		/**
		 * ��ʼ����ʾģʽ���л�����
		 */
		function initViewModeToggle() {
			// ����toggle
			var toggle = document.createElement('div');
			D.addClass(toggle, this.config.viewModeToggleCls);
			
			var span = document.createElement('span');
			span.innerHTML = this.config.viewModeTips[0];
			
			var plain = createAnchor.call(this, 'plain', this.config.viewModeTips[1]);
			var tab = createAnchor.call(this, 'tab', this.config.viewModeTips[2]);
			
			toggle.appendChild(span);
			toggle.appendChild(tab);
			toggle.appendChild(plain);
			
			this.container.appendChild(toggle);
			
			this.viewModeToggle = toggle;
			this.viewModeToggle['plain'] = plain;
			this.viewModeToggle['tab'] = tab;
			
			tweakViewModeToggle.call(this);
			
			function createAnchor(cls, txt) {
				var a = document.createElement('a');
				D.addClass(a, cls);
				a.href = "#";
				a.setAttribute('title', txt);
				a.innerHTML = '<span>' +txt + '</span>';
				E.on(a, 'click', function(e) { E.preventDefault(e); this.toggleViewMode(cls); }, null, this);
				return a;
			}
		}

		/**
		 * ������ʾģʽ�л����ص��ı�
		 */
		function tweakViewModeToggle() {
			var isPlain = (this.config.viewMode == 'plain');
			var plainCurrentCls = this.config.currentViewModeCls;
			var tabCurrentCls = this.config.currentViewModeCls;
			
			if(TAOBAO.env.ua.ie === 6) {
				plainCurrentCls = 'plain-' + plainCurrentCls;
				tabCurrentCls = 'tab-' + tabCurrentCls;
			}
			
			D[isPlain ? 'addClass' : 'removeClass'](this.viewModeToggle['plain'], plainCurrentCls);
			D[isPlain ? 'removeClass' : 'addClass'](this.viewModeToggle['tab'], tabCurrentCls);
			
		}
		
		/**
		 * ugly hacks for ie6
		 */
		function hackForIE6(tv) {
			if(TAOBAO.env.ua.ie === 6) {
				/* ��ie6��ȫ��չ��ʱ��panel�е�table��ʾ������ */
				D.setStyle(tv.panelsWrapper, 'zoom', '1');
				/* ��ie6��ȫ��չ��ʱ����һ��panel��ͷ������ʽ���� */
				tv.panels.forEach( function(panel) { D.setStyle(panel.head, 'zoom', '1'); } );
			}
		}
	// end of private members
	
	TAOBAO.extend(TabView, TAOBAO.widget.PanelList, {
		/**
		 * ����Tabҳ
		 */
		setActiveTab: function(index) {
			var len = this.panels.length;
			if(len < 1) return;
			
			// ֵ�Ƿ�ʱ��Ĭ��ѡ�е�һ��Tabҳ
			if(!(index in this.panels)) index = 0;
			
			var activePanel = this.panels[this.config.activeTabIndex];
			var newActivePanel = this.panels[index];

			// �����л�ǰ�¼�
			if(this.events['beforeSwitchTab'].fire(activePanel, newActivePanel) === false)
			 return;
			
			// �л��������ϵ���ʽ
			D.removeClass(activePanel.tabHead, this.config.activeTabCls);
			D.addClass(newActivePanel.tabHead, this.config.activeTabCls);

			// ��������
			D.setStyle(activePanel.getDom(), 'display', 'none');
			D.setStyle(newActivePanel.head, 'display', this.config.hiddenPanelHead ? 'none' : '');
			D.setStyle(newActivePanel.getDom(), 'display', '');
			if(newActivePanel.collapsed) {
				newActivePanel.expand(); // ��֤���ݿɼ�
			}
			
			// �����л����¼�
			this.events['onSwitchTab'].fire(activePanel, newActivePanel);
			
			// ����activeTabIndex	
			this.config.activeTabIndex = index;
			this.config.viewMode == 'tab';
			
			// location��Ӧ�仯����֤ˢ��ʱ������ǰ�����Tab
			if(this.config.parseHash) {
				var url = location.href.replace(location.hash, '');
				location.replace(url + this.panels[index].tabHead.anchor.name);
			}
		},
		
		/**
		 * �л�TabView����ʾģʽ
		 */
		toggleViewMode: function(mode) {
			var newViewMode = this.config.viewMode;
			if(mode == 'plain' || mode == 'tab') {
				newViewMode = mode;
			} else {
				newViewMode = newViewMode.toggle('plain', 'tab');
			}
			var toPlain = (newViewMode == 'plain');
			
			// �����¼�
			if(this.events['beforeToggleViewMode'].fire(this) === false) return;
			
			// ��ʾ/���� navBar
			D.setStyle(this.navBar, 'display', toPlain ? 'none' : '');
			
			// ����panelsWrapper�ĸ߶�
			this.panelsWrapper.style.height = toPlain ? 'auto' : '';
			
			// ��ʾ/���� panels
			// ���ü��߼�����
			this.panels.forEach(function(panel, index) {
				D.setStyle(panel.getDom(), 'display', toPlain ? '' : 'none');
				D.setStyle(panel.head, 'display', toPlain ? '' : 'none');
				
				// tab ģʽʱ����ʾ��ǰtab
				if(!toPlain && index == this.config.activeTabIndex) {
					D.setStyle(panel.head, 'display', this.config.hiddenPanelHead ? 'none' : '');
					D.setStyle(panel.getDom(), 'display', '');
					
					// panel �п�����collapsible�ģ���ͷ�������ص���ʱ����Ҫ��body��foot��ʾ����
					// ����tab��ʾģʽ�£���ǰTab�����ݿտ���
					if(panel.collapsed) { // && this.config.hiddenPanelHead) {
						panel.expand();
					}
					
					// ����ǰTab��nav������ʽ
					// �����ʼΪplain�����tabʱ���������ĵ�ǰTab��û����ʽ
					D.addClass(panel.tabHead, this.config.activeTabCls);
				}
			}, this);
			
			// �л�toggle���ı�����ʽ
			this.config.viewMode = newViewMode;
			tweakViewModeToggle.call(this);
			
			// �����¼�
			this.events['onToggleViewMode'].fire(this);
		}
	});
	
	return TabView;
}();

// ����decorate��̬����
TAOBAO.widget.TabView.decorate = function(container, listCfg, panelCfg) {
	return new TAOBAO.widget.TabView(container, listCfg, panelCfg);
};

/**
 * @class TAOBAO.widget.InputMask
 *
 * creator: yubo@taobao.com
 */

TAOBAO.widget.InputMask = function() {
	var L  = TAOBAO.lang,
		U  = TAOBAO.util,
		D  = TAOBAO.util.Dom,
		E  = TAOBAO.util.Event,
		Ef = TAOBAO.util.Effect;

	// Ĭ������
	var defConfig = {
			inputEl: null, // input Ԫ��
			formatMask: null, // ���������ֵ��Ҫ���������
			keyMask: null, // ����ļ�ֵ��Ҫ���������
			events: { }
		};
	
	/* private methods */
		/**
		 * Returns true if the key is a printable character.
		 */
		function isPrintable(keyCode) {
			return (keyCode >= 32 && keyCode < 127);
		}

		/**
		* Returns the key code associated with the event.
		*/
		function getKeyCode(e) {
		  return window.event ? window.event.keyCode : (e ? e.which : null);
		}
	/* end of private methods */
	
	var InputMask = function() {
		var args = arguments;
		if(args.length == 1) {
			init.call(this, args[0]); // new InputMask( { inputEl: 'id', maskRegex: /\d\d.\d\d/ } )
		} else if(args.length == 2) { // new InputMask('id', { maskRegex: /\d\d.\d\d/ } )
			if((typeof args[0] == 'string' || args[0].nodeType == 1) && typeof args[1] == 'object') {
				args[1].inputEl = args[0];
				init.call(this, args[1]);
			}
		} else {
			return null;
		}
	};

	function init(config) {
		this.config = L.applyIf(config || {}, defConfig);

		var cfg = this.config;
		this.inputEl = D.get(cfg.inputEl);
		if(!this.inputEl) return;
		if(!(cfg.keyMask instanceof RegExp)) return; // �����������ʽ��ֱ�ӷ���

		// �����¼�
		E.addEvents.apply(this, ['onRightInput', 'onErrorInput', 'onFinish']);
		
		// ��ֹ�Ƿ���������
		E.on(this.inputEl, 'keypress', function(e) {
			var keyCode = getKeyCode(e);
			if(!keyCode || !isPrintable(keyCode)) return;
			var key = String.fromCharCode(keyCode);
			
			if(!cfg.keyMask.test(key)) {
				this.events['onErrorInput'].fire(this);
				E.stopEvent(e);
			}
		}, null, this);
		
		// �����Ϸ������¼�
		// һ����˵��Del, Backspace���ǺϷ����룬��ʱֵ�ĺϷ��Եȵ�keyup����ʱ��У��ȽϷ���
		E.on(this.inputEl, 'keyup', function(e) {
			var keyCode = getKeyCode(e);
			if(!keyCode) return;
			if(!(cfg.formatMask instanceof RegExp)) return;
			
			this.value = this.inputEl.value;
			if(cfg.formatMask.test(this.value)) { // keyup�¼��ܱ�֤value�ǵ�ǰֵ	
				this.events['onRightInput'].fire(this);
			} else {
				this.events['onErrorInput'].fire(this);
			}
		}, null, this);
		
		// ������������¼�
		E.on(this.inputEl, 'blur', function(e) {
			this.value = this.inputEl.value;
			this.events['onFinish'].fire(this);
			this.value = this.inputEl.value; // ����value��������������¼����иĶ�
			
			// ��֤�Ƿ�����format
			if(cfg.formatMask instanceof RegExp) {
				if(!cfg.formatMask.test(this.value)) {
					this.events['onErrorInput'].fire(this);
				}
			}
		}, null, this);
	};
	
	return InputMask;
}();

// ����decorate��̬����
TAOBAO.widget.InputMask.decorate = function(inputEl, cfg) {
	return new TAOBAO.widget.InputMask(inputEl, cfg);
};
/*
 * Deprecated ugly code...
 *
 * creator: yubo@taobao.com
 */

/* 0.1.0 -> 0.2.0 */
	/**
	 * Ϊ�˱����YUI�о������ֵ�fireEvent��������ϵĻ���������ΪfireElEvent
	 * 2008/7/11 �Ƽ��嵥��Ŀ���к�̨������Ա���ô˷���
	 */
	TAOBAO.util.Event.fireEvent = TAOBAO.util.Event.fireElEvent;

/* EOF */